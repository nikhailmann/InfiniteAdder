public class Digit
{
    int value;
    Digit next;
    Digit prev;
}